//
//  ExchangeInfo.h
//  qiuFight
//
//  Created by 张跃东 on 16/5/18.
//
//

#import <UIKit/UIKit.h>

@interface UIImage (RoundedRectImage)
+ (UIImage *)createRoundedRectImage:(UIImage *)image withSize:(CGSize)size withRadius:(NSInteger)radius;

@end
