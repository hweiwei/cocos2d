#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>
#import <AVFoundation/AVFoundation.h>

@interface RootViewController : UIViewController<UIPickerViewDataSource, UIPickerViewDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIActionSheetDelegate>
{
    int photoIdx;
    BOOL isHorizontal;
}

@property (nonatomic, strong) NSString* province_name;


-(NSString*) getLocationProvince;

-(BOOL) startReading;
-(void) addPhoto:(int)idex;
-(void) setIsHorizontal:(BOOL)flag;
-(NSString*) setIconImage:(int)index;

@end
