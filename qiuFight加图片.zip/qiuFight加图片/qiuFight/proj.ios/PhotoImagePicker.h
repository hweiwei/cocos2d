//
//  PhotoImagePicker.h
//  qiuFight
//
//  Created by 张跃东 on 16/6/14.
//
//

#ifndef PhotoImagePicker_h
#define PhotoImagePicker_h

@interface PhotoImagePicker : UINavigationController<UIPickerViewDataSource, UIPickerViewDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIActionSheetDelegate>
{
    int photoIdx;
}


@end

#endif /* PhotoImagePicker_h */
