#import "RootViewController.h"
#import "SYQRCodeViewController.h"
#import "ExchangeInfo.h"
#import <MobileCoreServices/UTCoreTypes.h>
//#import "UIImagePickerController+PhotoImagePicker.h"
//#import "PhotoImagePicker.h"

@implementation RootViewController

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/
// Override to allow orientations other than the default portrait orientation.
// This method is deprecated on ios6
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return UIInterfaceOrientationIsLandscape( interfaceOrientation );
}

-(void)setIsHorizontal:(BOOL)flag
{
    isHorizontal = flag;
}

// For ios6, use supportedInterfaceOrientations & shouldAutorotate instead
- (NSUInteger) supportedInterfaceOrientations{
#ifdef __IPHONE_6_0
//    return UIInterfaceOrientationMaskAllButUpsideDown;
    if(isHorizontal)
        return UIInterfaceOrientationMaskLandscape;
    else
        return UIInterfaceOrientationMaskAll;
#endif
}

- (BOOL) shouldAutorotate {
    return YES;
}

-(NSUInteger)appliction:(UIApplication*) application supportedInterfaceOrientationsForWindow:(UIWindow*)window{
//    return UIInterfaceOrientationMaskAllButUpsideDown;
    return UIInterfaceOrientationMaskLandscape;
}

//fix not hide status on ios7
- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

-(NSString*) getLocationProvince
{
    return _province_name;
}

-(BOOL) startReading
{
    //扫描二维码
    SYQRCodeViewController *qrcodevc = [[SYQRCodeViewController alloc] init];
    qrcodevc.SYQRCodeSuncessBlock = ^(SYQRCodeViewController *aqrvc,NSString *qrString){
        //NSLog(qrString);
        const char* idStr = [qrString UTF8String];
        ExchangeInfo::SaomaAddFriend(idStr);

//        self.saomiaoLabel.text = qrString;
        [aqrvc dismissViewControllerAnimated:NO completion:nil];
    };
    qrcodevc.SYQRCodeFailBlock = ^(SYQRCodeViewController *aqrvc){
//        self.saomiaoLabel.text = @"fail~";
        [aqrvc dismissViewControllerAnimated:NO completion:nil];
    };
    qrcodevc.SYQRCodeCancleBlock = ^(SYQRCodeViewController *aqrvc){
        [aqrvc dismissViewControllerAnimated:NO completion:nil];
//        self.saomiaoLabel.text = @"cancle~";
    };
    [self presentViewController:qrcodevc animated:YES completion:nil];
}

-(void)addPhoto:(int)idxe{
//    PhotoImagePicker *ctrl = [[PhotoImagePicker alloc] init];
//    [self presentViewController:ctrl animated:YES completion:nil];
    
    [self setIsHorizontal:NO];
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                  initWithTitle:nil
                                  delegate:self
                                  cancelButtonTitle:@"取消"
                                  destructiveButtonTitle:nil
                                  otherButtonTitles:@"相册上传",nil];
    actionSheet.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [actionSheet showInView:self.view];
    
    
    photoIdx = idxe;
}

#pragma mark actionDelegate
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex == 1)
        return;
    else if(buttonIndex == 0)
    {
        if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
            NSLog(@"sorry, no camera or camera is unavailable!!!");
            return;
        }
        
        
        UIImagePickerController* imagePickerController = [[UIImagePickerController alloc] init];
        //设置图像选取控制器的来源模式为相机模式
        imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        //设置图像选取控制器的类型为动态图像
        imagePickerController.mediaTypes =[[NSArray alloc] initWithObjects:(NSString*)kUTTypeImage, nil];
        //允许用户进行编辑
        imagePickerController.allowsEditing = YES;
        //设置委托对象
        imagePickerController.delegate = self;
        //以模式视图控制器的形式显示
        imagePickerController.modalPresentationStyle=UIModalPresentationOverCurrentContext;
        [self presentViewController:imagePickerController animated:YES completion:nil];
    }
}

#pragma mark  拍照代理
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    UIImage* image = [self fixOrientation:[info objectForKey:@"UIImagePickerControllerOriginalImage"]];
    image = [self thumbnailWithImageWithoutScale:image size:CGSizeMake(300, 300)];
    NSString* dataStr = [self saveImage:image withName:@"head.jpg"];
    
    const char* str = [dataStr cStringUsingEncoding:NSUTF8StringEncoding];
    ExchangeInfo::UpLoadPhoto(str, photoIdx);    
    
    [picker dismissViewControllerAnimated:YES completion:nil];
}

-(void) imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark 处理照片旋转问题
-(UIImage *)fixOrientation:(UIImage *)aImage{
    if (aImage.imageOrientation==UIImageOrientationUp) {
        return aImage;
    }
    CGAffineTransform transform=CGAffineTransformIdentity;
    switch (aImage.imageOrientation) {
        case UIImageOrientationDown:
        case UIImageOrientationDownMirrored:
            transform=CGAffineTransformTranslate(transform,aImage.size.width,aImage.size.height);
            transform=CGAffineTransformRotate(transform, M_PI);
            break;
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
            transform=CGAffineTransformTranslate(transform, aImage.size.width, 0);
            transform=CGAffineTransformRotate(transform, M_PI_2);
            break;
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            transform=CGAffineTransformTranslate(transform, 0, aImage.size.height);
            transform=CGAffineTransformRotate(transform, -M_PI_2);
            break;
        default:
            break;
    }
    switch (aImage.imageOrientation) {
        case UIImageOrientationUpMirrored:
        case UIImageOrientationDownMirrored:
            transform=CGAffineTransformTranslate(transform, aImage.size.width, 0);
            transform=CGAffineTransformScale(transform, -1, 1);
            break;
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRightMirrored:
            transform=CGAffineTransformTranslate(transform, aImage.size.height, 0);
            transform=CGAffineTransformScale(transform, -1, 1);
            break;
        default:
            break;
    }
    CGContextRef ctx=CGBitmapContextCreate(NULL, aImage.size.width, aImage.size.height, CGImageGetBitsPerComponent(aImage.CGImage), 0, CGImageGetColorSpace(aImage.CGImage), CGImageGetBitmapInfo(aImage.CGImage));
    CGContextConcatCTM(ctx, transform);
    switch (aImage.imageOrientation) {
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            // Grr...
            CGContextDrawImage(ctx, CGRectMake(0,0,aImage.size.height,aImage.size.width), aImage.CGImage);
            break;
            
        default:
            CGContextDrawImage(ctx, CGRectMake(0,0,aImage.size.width,aImage.size.height), aImage.CGImage);
            break;
    }
    
    // And now we just create a new UIImage from the drawing context
    CGImageRef cgimg = CGBitmapContextCreateImage(ctx);
    UIImage *img = [UIImage imageWithCGImage:cgimg];
    CGContextRelease(ctx);
    CGImageRelease(cgimg);
    return img;
    
}

// 保存图片到document， 并返回地址
-(NSString*) saveImage:(UIImage*)currentImage withName:(NSString*)imageName{
    NSData* imageData = UIImageJPEGRepresentation(currentImage, 0.3f);
    //获取沙盒目录
    NSString* photoName = [NSString stringWithFormat:@"/headImage%d.jpg", photoIdx];
    
    NSArray* paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString* fullPath = [[paths objectAtIndex:0] stringByAppendingString:photoName];
    // 将图片写入文件
    [imageData writeToFile:fullPath atomically:NO];
    
    // image转成str；
    NSString *dataStr = [imageData base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
    return dataStr;
}

// 设置尺寸
-(UIImage*)imageWithImageSimple:(UIImage*)image scaledToSize:(CGSize)newSize
{
    UIGraphicsBeginImageContext(newSize);
    [image drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}

//2.保持原来的长宽比，生成一个缩略图
- (UIImage *)thumbnailWithImageWithoutScale:(UIImage *)image size:(CGSize)asize
{
    UIImage *newimage;
    if (nil == image) {
        newimage = nil;
    }
    else{
        CGSize oldsize = image.size;
        CGRect rect;
        if (asize.width/asize.height > oldsize.width/oldsize.height) {
            rect.size.width = asize.height*oldsize.width/oldsize.height;
            rect.size.height = asize.height;
            rect.origin.x = (asize.width - rect.size.width)/2;
            rect.origin.y = 0;
        }
        else{
            rect.size.width = asize.width;
            rect.size.height = asize.width*oldsize.height/oldsize.width;
            rect.origin.x = 0;
            rect.origin.y = (asize.height - rect.size.height)/2;
        }
        UIGraphicsBeginImageContext(asize);
        CGContextRef context = UIGraphicsGetCurrentContext();
        CGContextSetFillColorWithColor(context, [[UIColor clearColor] CGColor]);
        UIRectFill(CGRectMake(0, 0, asize.width, asize.height));//clear background
        [image drawInRect:rect];
        newimage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
    }
    return newimage;
}

-(NSString*)setIconImage:(int)index{
    //获取沙盒目录
    NSString* photoName = [NSString stringWithFormat:@"/headImage%d.jpg", index];
    
    NSArray* paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString* fullPath = [[paths objectAtIndex:0] stringByAppendingString:photoName];
    
    NSFileManager* fileManager = [NSFileManager defaultManager];
    if(![fileManager fileExistsAtPath:fullPath])
        return @"";
    
    UIImage* image = [UIImage imageNamed:fullPath];
    image = [self thumbnailWithImageWithoutScale:image size:CGSizeMake(80, 80)];
    
    NSData* iconData = UIImageJPEGRepresentation(image, 0.8f);
    // 自己直接压缩照片，这个icon主要是给别人看
//    NSString* iconPath = [[paths objectAtIndex:0] stringByAppendingString:@"/icon.jpg"];
//    [iconData writeToFile:iconPath atomically:NO];
    
    NSString* dataStr = [iconData base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
    return dataStr;
}

@end
