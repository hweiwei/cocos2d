//
//  PhotoImagePicker.m
//  qiuFight
//
//  Created by 张跃东 on 16/6/14.
//
//

#import "PhotoImagePicker.h"
#import <MobileCoreServices/UTCoreTypes.h>

#define kDeviceWidth [UIScreen mainScreen].bounds.size.width
#define KDeviceHeight [UIScreen mainScreen].bounds.size.height

@implementation PhotoImagePicker

-(void)viewDidLoad
{
    
    [super viewDidLoad];
    
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                  initWithTitle:nil
                                  delegate:self
                                  cancelButtonTitle:@"取消"
                                  destructiveButtonTitle:nil
                                  otherButtonTitles:@"相册上传",nil];
    actionSheet.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [actionSheet showInView:self.view];
    
    photoIdx = 0;
}

#pragma mark actionDelegate
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex == 1)
        return;
    else if(buttonIndex == 0)
    {
        
        if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]) {
            NSLog(@"sorry, no camera or camera is unavailable!!!");
            return;
        }
        
        UIImagePickerController* imagePickerController = [[UIImagePickerController alloc] init];
        //设置图像选取控制器的来源模式为相机模式
        imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        //设置图像选取控制器的类型为动态图像
        imagePickerController.mediaTypes =[[NSArray alloc] initWithObjects:(NSString*)kUTTypeImage, nil];
        //允许用户进行编辑
        imagePickerController.allowsEditing = YES;
        //设置委托对象
        imagePickerController.delegate = self;
        //以模式视图控制器的形式显示
        imagePickerController.modalPresentationStyle=UIModalPresentationOverCurrentContext;
        [self presentViewController:imagePickerController animated:YES completion:nil];
    }
}

// For ios6, use supportedInterfaceOrientations & shouldAutorotate instead
- (NSUInteger) supportedInterfaceOrientations{
#ifdef __IPHONE_6_0
    //return UIInterfaceOrientationMaskPortrait;
    return UIInterfaceOrientationMaskAll;
#endif
}

- (BOOL) shouldAutorotate {
    return NO;
}

#pragma mark  拍照代理
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    UIImage* image = [self fixOrientation:[info objectForKey:@"UIImagePickerControllerOriginalImage"]];
    image = [self imageWithImageSimple:image scaledToSize:CGSizeMake(300, 300)];
    NSString* dataStr = [self saveImage:image withName:@"head.jpg"];
    
//    const char* str = [dataStr cStringUsingEncoding:NSUTF8StringEncoding];
//    ExchangeInfo::UpLoadPhoto(str, photoIdx);
    
    [picker dismissViewControllerAnimated:YES completion:nil];
}

-(void) imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark 处理照片旋转问题
-(UIImage *)fixOrientation:(UIImage *)aImage{
    if (aImage.imageOrientation==UIImageOrientationUp) {
        return aImage;
    }
    CGAffineTransform transform=CGAffineTransformIdentity;
    switch (aImage.imageOrientation) {
        case UIImageOrientationDown:
        case UIImageOrientationDownMirrored:
            transform=CGAffineTransformTranslate(transform,aImage.size.width,aImage.size.height);
            transform=CGAffineTransformRotate(transform, M_PI);
            break;
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
            transform=CGAffineTransformTranslate(transform, aImage.size.width, 0);
            transform=CGAffineTransformRotate(transform, M_PI_2);
            break;
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            transform=CGAffineTransformTranslate(transform, 0, aImage.size.height);
            transform=CGAffineTransformRotate(transform, -M_PI_2);
            break;
        default:
            break;
    }
    switch (aImage.imageOrientation) {
        case UIImageOrientationUpMirrored:
        case UIImageOrientationDownMirrored:
            transform=CGAffineTransformTranslate(transform, aImage.size.width, 0);
            transform=CGAffineTransformScale(transform, -1, 1);
            break;
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRightMirrored:
            transform=CGAffineTransformTranslate(transform, aImage.size.height, 0);
            transform=CGAffineTransformScale(transform, -1, 1);
            break;
        default:
            break;
    }
    CGContextRef ctx=CGBitmapContextCreate(NULL, aImage.size.width, aImage.size.height, CGImageGetBitsPerComponent(aImage.CGImage), 0, CGImageGetColorSpace(aImage.CGImage), CGImageGetBitmapInfo(aImage.CGImage));
    CGContextConcatCTM(ctx, transform);
    switch (aImage.imageOrientation) {
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            // Grr...
            CGContextDrawImage(ctx, CGRectMake(0,0,aImage.size.height,aImage.size.width), aImage.CGImage);
            break;
            
        default:
            CGContextDrawImage(ctx, CGRectMake(0,0,aImage.size.width,aImage.size.height), aImage.CGImage);
            break;
    }
    
    // And now we just create a new UIImage from the drawing context
    CGImageRef cgimg = CGBitmapContextCreateImage(ctx);
    UIImage *img = [UIImage imageWithCGImage:cgimg];
    CGContextRelease(ctx);
    CGImageRelease(cgimg);
    return img;
    
}

// 保存图片到document， 并返回地址
-(NSString*) saveImage:(UIImage*)currentImage withName:(NSString*)imageName{
    NSData* imageData = UIImageJPEGRepresentation(currentImage, 0.2f);
    //获取沙盒目录
    NSString* photoName = [NSString stringWithFormat:@"headImage%d.jpg", photoIdx];
    NSString* fullPath = [NSTemporaryDirectory() stringByAppendingPathComponent:photoName];
    // 将图片写入文件
    [imageData writeToFile:fullPath atomically:NO];
    
    NSString *dataStr = [[NSString alloc] initWithData:imageData encoding:NSUTF8StringEncoding];
    return dataStr;
}

// 设置尺寸
-(UIImage*)imageWithImageSimple:(UIImage*)image scaledToSize:(CGSize)newSize
{
    UIGraphicsBeginImageContext(newSize);
    [image drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}

@end
