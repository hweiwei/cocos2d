#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>

@class RootViewController;

@interface AppController : NSObject <UIApplicationDelegate, CLLocationManagerDelegate> {
    UIWindow *window;
    RootViewController    *viewController;
    CLLocationManager*      _locationManager;
    NSString*   _province;
}

@end

