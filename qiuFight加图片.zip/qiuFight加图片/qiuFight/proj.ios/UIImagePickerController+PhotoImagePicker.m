//
//  PhotoImagePicker.m
//  qiuFight
//
//  Created by 张跃东 on 16/6/14.
//
//

#import "UIImagePickerController+PhotoImagePicker.h"

@implementation UIImagePickerController (PhotoImagePicker)


- (BOOL) shouldAutorotate {
    return YES;
}

// For ios6, use supportedInterfaceOrientations & shouldAutorotate instead
- (NSUInteger) supportedInterfaceOrientations{
#ifdef __IPHONE_6_0
    return UIInterfaceOrientationMaskLandscape;
#endif
}


@end
