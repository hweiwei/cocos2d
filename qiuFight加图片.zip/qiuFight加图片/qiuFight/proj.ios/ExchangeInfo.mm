//
//  ExchangeInfo.m
//  qiuFight
//
//  Created by 张跃东 on 16/5/18.
//
//
#import <UIKit/UIKit.h>
#import "ExchangeInfo.h"
#import "KMQRCode.h"
#import "UIImage+RoundedRectImage.h"
#import "JsonHandler.h"
#import "AppController.h"
#import "RootViewController.h"


std::string ExchangeInfo::getIdentifier()
{
    NSString* identifierForVendor = [[UIDevice currentDevice].identifierForVendor UUIDString];
    const char* ident = [identifierForVendor UTF8String];
    return ident;
}


void ProviderReleaseData (void *info, const void *data, size_t size){
    free((void*)data);
}


void ExchangeInfo::CreateQRFImage(const char* str,const char* headIcon,float mSize)
{
    
    NSString* qrString = [NSString stringWithUTF8String:str];
    CIImage* imgQRCode = [KMQRCode createQRCodeImage:qrString];
    UIImage* mImage = [KMQRCode resizeQRCodeImage:imgQRCode withSize:mSize];
    mImage = [KMQRCode specialColorImage:mImage withRed:255 green:0 blue:0];
 
    NSString* headimage = [NSString stringWithUTF8String:headIcon];
    UIImage* imgIcon = [UIImage createRoundedRectImage:[UIImage imageNamed:headimage] withSize:CGSizeMake(mSize*0.3f, mSize*0.3f) withRadius:5];
    UIImage* resultImage = [KMQRCode addIconToQRCodeImage:mImage withIcon:imgIcon withIconSize:imgIcon.size];
    
    /////////////////////////////////////////////////////////////////////
    ///保存图片
    //////////////////////////////////////////////////////////////////////
    NSFileManager* fileManager = [NSFileManager defaultManager];
    NSArray* paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSData* data = UIImageJPEGRepresentation(resultImage, 1.0);
    NSString* DocuPath = NULL;
    
    //stNotPlayerData mPlayerInfo = Global::getInstance()->getPlayerData();
    
    DocuPath = [[paths objectAtIndex:0] stringByAppendingString:@"/qrf"];
    if(![fileManager fileExistsAtPath:DocuPath])
    {
        [fileManager createDirectoryAtPath:DocuPath withIntermediateDirectories:NO attributes:nil error:nil];
    }
    
    NSString* uniquePath = [DocuPath stringByAppendingString:@"/qrf.png"];
    BOOL blHave = [fileManager fileExistsAtPath:uniquePath];
    
    if(blHave)
    {
        BOOL blDele = [fileManager removeItemAtPath:uniquePath error:nil];
        if(blDele)
        {
            NSLog(@"delete success");
        }
        else
        {
            NSLog(@"delete fail");
        }
    }
    [data writeToFile:uniquePath atomically:YES];
    [fileManager fileSystemRepresentationWithPath:DocuPath];
    
}

std::map<int,std::string> ExchangeInfo::getProvinces()
{
    std::map<int,std::string> infos;
    
    NSString* fullPath = [[NSBundle mainBundle] pathForResource:@"province" ofType:@"json"];
    NSFileManager* fileManager = [NSFileManager defaultManager];
    if([fileManager fileExistsAtPath:fullPath])
    {
        NSData* data = [NSData dataWithContentsOfFile:fullPath];
        NSDictionary* dics = [JsonHandler JSONValueByData:data];
        NSMutableArray* arr = [dics objectForKey:@"data"];
        for( int i = 0; i < arr.count; i++ )
        {
            NSDictionary* dic = [arr objectAtIndex:i];
            NSString* provinceS = [dic objectForKey:@"name"];
            NSString* mID = [dic objectForKey:@"id"];
            std::string name = [provinceS UTF8String];
            std::string mIDStr = [mID UTF8String];
            int idr = atoi(mIDStr.c_str());
            infos[idr] = name;
        }
    }
    
    
    return infos;
}

int ExchangeInfo::getLocationProvince()
{
    RootViewController* ctrl = [UIApplication sharedApplication].keyWindow.rootViewController;
    NSString* temp = [ctrl getLocationProvince];
    if(temp == "" || [temp length] == 0)
        return 0;
    NSString* fullPath = [[NSBundle mainBundle] pathForResource:@"province" ofType:@"json"];
    NSFileManager* fileManager = [NSFileManager defaultManager];
    if([fileManager fileExistsAtPath:fullPath])
    {
        NSData* data = [NSData dataWithContentsOfFile:fullPath];
        NSDictionary* dics = [JsonHandler JSONValueByData:data];
        NSMutableArray* arr = [dics objectForKey:@"data"];
        for( int i = 0; i < arr.count; i++ )
        {
            NSDictionary* dic = [arr objectAtIndex:i];
            NSString* provinceS = [dic objectForKey:@"name"];
            if([provinceS isEqualToString:temp])
            {
                int proID = [[dic objectForKey:@"id"] intValue];
                return proID;
            }
        }
    }
    return 0;
}

void ExchangeInfo::OpenScan()
{
    RootViewController* ctrl = [UIApplication sharedApplication].keyWindow.rootViewController;
//    ScanViewController* scan = [[ScanViewController alloc] init];
//    [ctrl.view addSubview:scan.view ];
    [ctrl startReading];
}

void ExchangeInfo::SaomaAddFriend(const char* str)
{
    int rolID = atoi(str);
    MainScene* scene = (MainScene*)CCDirector::sharedDirector()->getRunningScene()->getChildByTag(0);
    scene->reqAddFriend(rolID, "");
}

void ExchangeInfo::AddPhoto(int idex)
{
    RootViewController* ctrl = [UIApplication sharedApplication].keyWindow.rootViewController;
    [ctrl addPhoto:idex];
}

void ExchangeInfo::UpLoadPhoto(const char *str, int index)
{
    MainScene* scene = (MainScene*)CCDirector::sharedDirector()->getRunningScene()->getChildByTag(0);
    scene->reqSendPhoto(index, str);
}

void ExchangeInfo::UpLoadIcon(int index)
{
    RootViewController* ctrl = [UIApplication sharedApplication].keyWindow.rootViewController;
    NSString* dataStr = [ctrl setIconImage:index];
    const char* str = [dataStr cStringUsingEncoding:NSUTF8StringEncoding];
    
    MainScene* scene = (MainScene*)CCDirector::sharedDirector()->getRunningScene()->getChildByTag(0);
    scene->reqSetIcon(index, str);
}

cocos2d::CCTexture2D * ExchangeInfo::GetTextureForData(const char* data)
{
    NSString* nsData = [[NSString alloc] initWithCString:data encoding:NSUTF8StringEncoding];
    NSData* fileData = [[NSData alloc] initWithBase64Encoding:nsData];
    UIImage* image = [UIImage imageWithData:fileData];
    
    CGImageRef imageRef = [image CGImage];
    NSUInteger width = CGImageGetWidth(imageRef);
    NSUInteger height = CGImageGetHeight(imageRef);
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    unsigned char* rawData = (unsigned char*) calloc(height * width * 4, sizeof(unsigned char));
    NSUInteger bytesPerPixel = 4;
    NSUInteger bytesPerRow = bytesPerPixel * width;
    NSUInteger bitsPerComponent = 8;
    CGContextRef context = CGBitmapContextCreate(rawData, width, height, bitsPerComponent, bytesPerRow, colorSpace, kCGImageAlphaPremultipliedLast | kCGBitmapByteOrder32Big);
    CGColorSpaceRelease(colorSpace);
    CGContextDrawImage(context, CGRectMake(0, 0, width, height), imageRef);
    CGContextRelease(context);
    cocos2d::CCTexture2D *pickedImage = new cocos2d::CCTexture2D();
    pickedImage->initWithData(rawData, cocos2d::kCCTexture2DPixelFormat_RGBA8888, (unsigned int)width, (unsigned int)height, cocos2d::CCSizeMake(width, height));
    
    return pickedImage;
}
void ExchangeInfo::SaveImag(const char* imgdata,const char* destpath)
{
    NSString* nsData = [[NSString alloc] initWithCString:imgdata encoding:NSUTF8StringEncoding];
    NSData* fileData = [[NSData alloc] initWithBase64Encoding:nsData];
    UIImage* image = [UIImage imageWithData:fileData];
    
    NSFileManager* fileManager = [NSFileManager defaultManager];
    NSArray* paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSData* data = UIImageJPEGRepresentation(image, 1.0);
    NSString* DocuPath = NULL;
    
    //stNotPlayerData mPlayerInfo = Global::getInstance()->getPlayerData();
    NSString* imagname = [NSString stringWithUTF8String:destpath];
    
    DocuPath = [[paths objectAtIndex:0] stringByAppendingString:imagname];
    if(![fileManager fileExistsAtPath:DocuPath])
    {
        [fileManager createDirectoryAtPath:DocuPath withIntermediateDirectories:NO attributes:nil error:nil];
    }
    
    NSString* uniquePath = DocuPath;//[DocuPath stringByAppendingString:imagname];
    BOOL blHave = [fileManager fileExistsAtPath:uniquePath];
    
    if(blHave)
    {
        BOOL blDele = [fileManager removeItemAtPath:uniquePath error:nil];
        if(blDele)
        {
            NSLog(@"delete success");
        }
        else
        {
            NSLog(@"delete fail");
        }
    }
    [data writeToFile:uniquePath atomically:YES];
    [fileManager fileSystemRepresentationWithPath:DocuPath];
}
bool ExchangeInfo::regexStr(const char* str,const char* dec)
{
    NSRange r;
    NSString *src= [NSString stringWithCString:str encoding:NSUTF8StringEncoding];
    NSString *regEx = [NSString stringWithCString:dec encoding:NSUTF8StringEncoding];
    r = [src rangeOfString:regEx options:NSRegularExpressionSearch];
    if (r.location != NSNotFound) {
        return true;
    }
    return false;
}

